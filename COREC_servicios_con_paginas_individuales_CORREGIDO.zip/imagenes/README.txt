Carpeta reservada para las imágenes de CODEC. El diseño actual funciona sin imágenes externas.
